<table>
 <thead>
   <tr>	
     <th>Version</th>
     <th>Auteur</th>
	 <th>Date</th>
	 <th>Description</th>
   </tr>
 <thead>
 <tbody>
 	<tr>
     <td>3.0</td>
     <td>JTH</td>
	 <td>15/03/2018</td>
	 <td>Ajout de badge avec le nombre de mouvement sur l'onglet</td>
   </tr>
 	<tr>
     <td>3.0</td>
     <td>JTH</td>
	 <td>15/03/2018</td>
	 <td>Ajout d'une page setup</td>
   </tr>
 	<tr>
     <td>3.0</td>
     <td>JTH</td>
	 <td>15/03/2018</td>
	 <td>Refonte de l'affichage des mouvement de consommation</td>
   </tr>
	<tr>
     <td>2.0</td>
     <td>JTH</td>
	 <td>27/01/2018</td>
	 <td>Ajout des champs fk_origin et origintype dans le mouvement</td>
   </tr>
   <tr>
     <td>2.0</td>
     <td>JTH</td>
	 <td>27/01/2018</td>
	 <td>Traçage du mouvement par Inventory Code</td>
   </tr>
   <tr>
     <td>2.0</td>
     <td>JTH</td>
	 <td>27/01/2018</td>
	 <td>Ajout des constantes CONSUMPTION_SEARCHMODE et CONSUMPTION_INVCODEPREFIX</td>
   </tr>
 </tbody>
</table>
